import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:iconsax/iconsax.dart';
import 'package:yt_ecommerce_admin_panel/common/widgets/appbar/appbar.dart';
import 'package:yt_ecommerce_admin_panel/common/widgets/images/t_circular_image.dart';
import 'package:yt_ecommerce_admin_panel/common/widgets/texts/section_heading.dart';
import 'package:yt_ecommerce_admin_panel/features/personalization/screens/profile/widgets/profile_menu.dart';
import 'package:yt_ecommerce_admin_panel/utils/constants/image_strings.dart';
import 'package:yt_ecommerce_admin_panel/utils/constants/sizes.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const TAppBar(title: Text('Profile'),showBackArrow: true,),
      ///  --  Body
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(TSizes.defaultSpace),
        child: Column(
          children: [
            /// Profile Picture
            SizedBox(
              width: double.infinity,
              child: Column(children: [
                const TCircularImage(image: TImages.user,width: 80,height: 80,),
                TextButton(onPressed: () {}, child: const Text('Change Profile Picture'),),
              ],),
            ),

            /// Details
            const SizedBox(height: TSizes.spaceBtwItems / 2),
            const Divider(),
            const SizedBox(height: TSizes.spaceBtwItems),

            ///  --  Heading Profile Info
            const TSectionHeading(title: 'Profile Information',showActionButton: false),
            const SizedBox(height: TSizes.spaceBtwItems),

            TProfileMenu(onPressed: () {  }, title: 'Name', value: 'Nirav Nasit',),
            TProfileMenu(onPressed: () {  }, title: 'Username', value: 'nirav_nasit_09',),


            const SizedBox(height: TSizes.spaceBtwItems / 2),
            const Divider(),
            const SizedBox(height: TSizes.spaceBtwItems),


            ///  --  Heading Personal Info
            const TSectionHeading(title: 'Profile Information',showActionButton: false),
            const SizedBox(height: TSizes.spaceBtwItems),

            TProfileMenu(onPressed: () {  }, title: 'User ID', value: '12345',icon: Iconsax.copy,),
            TProfileMenu(onPressed: () {  }, title: 'E-Mail', value: 'niravnasit0351@gmail.com',),
            TProfileMenu(onPressed: () {  }, title: 'Phone Number', value: '+91 9173542299',),
            TProfileMenu(onPressed: () {  }, title: 'Gender', value: 'Male',),
            TProfileMenu(onPressed: () {  }, title: 'DAte of Birth', value: '06 May 2004',),
            const Divider(),
            const SizedBox(height: TSizes.spaceBtwItems),

            Center(
              child: TextButton(onPressed: () {}, child: const Text('Close Account',style: TextStyle(color: Colors.red),)),
            ),



          ],
        ),
      ),
    );
  }
}
